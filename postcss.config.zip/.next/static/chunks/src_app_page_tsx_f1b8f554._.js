(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_3e6bcafe._.js",
  "static/chunks/node_modules_zod_v4_c00cc4c6._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_d8000710._.js",
  "static/chunks/src_e4e7a05f._.js"
],
    source: "dynamic"
});
